import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class AttendanceRecords extends StatefulWidget {
  @override
  _AttendanceRecordsState createState() => _AttendanceRecordsState();
}

class _AttendanceRecordsState extends State<AttendanceRecords> {
  String? fullName;
  String? matricNumber;
  String? userYear;
  String? section;
  String? course;

  int totalClasses = 0;
  int totalPresent = 0;
  int totalAbsent = 0;

  List<dynamic> classDetails = [];
  bool isClassDetailsVisible = false;
  String attendanceMessage = "";
  List<dynamic> attendanceRecords = [];

  bool isClassDataVisible = false;
  bool isAttendanceDataVisible = false;

  @override
  void initState() {
    super.initState();
    _loadStudentData();
    _fetchTotalClasses();
    _fetchTotalAttendance();
  }

  Future<String?> _getUserEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_email');
  }

  Future<void> _loadStudentData() async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) return;

      final response = await http.post(
        Uri.parse('http://192.168.0.18/get_student_details.php'),
        body: {'email': userEmail.trim()},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          setState(() {
            fullName = data['data']['fullName'];
            matricNumber = data['data']['matricNumber'];
            userYear = data['data']['year'];
            section = data['data']['section'];
            course = data['data']['course'];
          });
        }
      }
    } catch (e) {
      _showAlertDialog("Error: $e");
    }
  }

  Future<void> _fetchTotalClasses() async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) {
        _showAlertDialog("User email not found.");
        return;
      }

      final response = await http.post(
        Uri.parse('http://192.168.0.18/get_total_classes.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': userEmail.trim()}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['success']) {
          setState(() {
            totalClasses = data['total_classes'] ?? 0;
          });
        } else {
          _showAlertDialog(data['message'] ?? "Error fetching total classes.");
        }
      }
    } catch (e) {
      _showAlertDialog("Error: $e");
    }
  }

  Future<void> _fetchAttendanceRecords({required String status}) async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) return;

      setState(() {
        attendanceRecords = [];
        attendanceMessage = "";
      });

      final response = await http.post(
        Uri.parse('http://192.168.0.18/get_attendance_records.php'),
        body: {
          'email': userEmail.trim(),
          'status': status,
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        if (data['success']) {
          setState(() {
            attendanceRecords = data['attendance_records']?.toSet()?.toList() ?? [];
            attendanceMessage = attendanceRecords.isEmpty
                ? "No ${status.toLowerCase()} records found."
                : "";
          });
        } else {
          setState(() {
            attendanceMessage = data['message'] ?? "No records found.";
          });
        }
      } else {
        _showAlertDialog("Failed to load attendance records. Please try again.");
      }
    } catch (e) {
      _showAlertDialog("Error: $e");
    }
  }

  Future<void> _fetchTotalAttendance() async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) {
        _showAlertDialog("User email not found.");
        return;
      }

      // Fetch the attendance records for "Present"
      final responsePresent = await http.post(
        Uri.parse('http://192.168.0.18/get_attendance_records.php'),
        body: {'email': userEmail.trim(), 'status': 'Present'},
      );

      // Fetch the attendance records for "Absent"
      final responseAbsent = await http.post(
        Uri.parse('http://192.168.0.18/get_attendance_records.php'),
        body: {'email': userEmail.trim(), 'status': 'Absent'},
      );

      if (responsePresent.statusCode == 200 && responseAbsent.statusCode == 200) {
        final dataPresent = jsonDecode(responsePresent.body);
        final dataAbsent = jsonDecode(responseAbsent.body);

        if (dataPresent['success'] && dataAbsent['success']) {
          setState(() {
            // Set totalPresent and totalAbsent based on the attendance records length
            totalPresent = dataPresent['attendance_records']?.length ?? 0;
            totalAbsent = dataAbsent['attendance_records']?.length ?? 0;
          });
        } else {
          _showAlertDialog(dataPresent['message'] ?? "Failed to fetch attendance data.");
        }
      } else {
        _showAlertDialog("Failed to connect to server.");
      }
    } catch (e) {
      _showAlertDialog("Error: $e");
    }
  }

  Future<void> _fetchClassDetails() async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) {
        _showAlertDialog("User email not found.");
        return;
      }

      setState(() {
        classDetails = [];
      });

      final response = await http.post(
        Uri.parse('http://192.168.0.18/get_class_details.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': userEmail.trim()}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          setState(() {
            classDetails = (data['classes'] as List<dynamic>).toSet().toList();
            isClassDataVisible = classDetails.isNotEmpty;
          });
        } else {
          _showAlertDialog(data['message'] ?? "No classes found.");
        }
      } else {
        _showAlertDialog("Failed to fetch data.");
      }
    } catch (e) {
      _showAlertDialog("Error: $e");
    }
  }

  void _showAlertDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Message'),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              child: Text('OK'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _toggleClassDataVisibility() async {
    setState(() {
      isClassDataVisible = !isClassDataVisible;
    });

    if (isClassDataVisible) {
      await _fetchClassDetails();
    }
  }

  Future<void> _showDeleteConfirmationDialog(String subjectName) async {
    return showDialog<void>(
      context: context,
      barrierDismissible: false, // Prevent dismissing by tapping outside
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Confirm Deletion'),
          content: Text('Are you sure you want to delete the subject "$subjectName"?'),
          actions: <Widget>[
            TextButton(
              child: Text('Cancel'),
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog without deleting
              },
            ),
            TextButton(
              child: Text('Delete'),
              onPressed: () async {
                Navigator.of(context).pop(); // Close the dialog before deletion
                await _deleteClassByName(subjectName); // Call delete function
              },
            ),
          ],
        );
      },
    );
  }

  Future<void> _deleteClassByName(String subjectName) async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) return;

      final response = await http.post(
        Uri.parse('http://192.168.0.18/delete_subject.php'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({'email': userEmail.trim(), 'subject_name': subjectName}),
      );

      final data = jsonDecode(response.body);

      if (data['success']) {
        setState(() {
          classDetails.removeWhere((classInfo) => classInfo['subject_name'] == subjectName);
          totalClasses -= 1;
        });
        _showAlertDialog("Subject '$subjectName' deleted successfully.");
      } else {
        _showAlertDialog(data['message'] ?? "Failed to delete subject.");
      }
    } catch (e) {
      _showAlertDialog("Error: $e");
    }
  }


  void _togglePresentDataVisibility() {
    setState(() {
      isAttendanceDataVisible = !isAttendanceDataVisible;
    });

    if (isAttendanceDataVisible) {
      _fetchAttendanceRecords(status: 'Present');
    }
  }

  void _toggleAbsentDataVisibility() {
    setState(() {
      isAttendanceDataVisible = !isAttendanceDataVisible;
    });

    if (isAttendanceDataVisible) {
      _fetchAttendanceRecords(status: 'Absent');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Attendance Records',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: Color(0xFF10375C),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              child: SizedBox(
                width: MediaQuery.of(context).size.width * 0.9,
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Full Name: ${fullName ?? 'Loading...'}",
                          style: TextStyle(fontSize: 16)),
                      SizedBox(height: 8),
                      Text("Matric Number: ${matricNumber ?? 'Loading...'}",
                          style: TextStyle(fontSize: 16)),
                      SizedBox(height: 8),
                      Text("Year: ${userYear ?? 'Loading...'}",
                          style: TextStyle(fontSize: 16)),
                      SizedBox(height: 8),
                      Text("Section: ${section ?? 'Loading...'}",
                          style: TextStyle(fontSize: 16)),
                      SizedBox(height: 8),
                      Text("Course: ${course ?? 'Loading...'}",
                          style: TextStyle(fontSize: 16)),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                SizedBox(
                  width: 105.0,
                  height: 60.0,
                  child: ElevatedButton(
                    onPressed: _toggleClassDataVisibility,
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.black,
                      backgroundColor: Colors.green,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Classes", style: TextStyle(color: Colors.white)),
                        SizedBox(height: 4),
                        Text(
                          "$totalClasses",
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  width: 105.0,
                  height: 60.0,
                  child: ElevatedButton(
                    onPressed: _togglePresentDataVisibility,
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.black,
                      backgroundColor: Colors.blue,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Present", style: TextStyle(color: Colors.white)),
                        SizedBox(height: 4),
                        Text(
                          "$totalPresent",
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  width: 105.0,
                  height: 60.0,
                  child: ElevatedButton(
                    onPressed: _toggleAbsentDataVisibility,
                    style: ElevatedButton.styleFrom(
                      foregroundColor: Colors.black,
                      backgroundColor: Colors.red,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Absent", style: TextStyle(color: Colors.white)),
                        SizedBox(height: 4),
                        Text(
                          "$totalAbsent",
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            if (isClassDataVisible)
              Expanded(
                child: ListView.builder(
                  itemCount: classDetails.length,
                  itemBuilder: (context, index) {
                    var record = classDetails[index];
                    return Card(
                      margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      elevation: 4.0,
                      child: Row(
                        children: [
                          Container(
                            width: 8.0,
                            height: 90,
                            decoration: BoxDecoration(
                              color: Colors.deepPurple,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(15),
                                bottomLeft: Radius.circular(15),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    record['subject_name'] ?? 'Loading...',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black87,
                                    ),
                                  ),
                                  SizedBox(height: 6),
                                  Text(
                                    "Lecturer: ${record['lecturer_name'] ?? 'Loading...'}",
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.blueGrey,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                          IconButton(
                            icon: Icon(Icons.delete, color: Colors.red),
                            onPressed: () {
                              _showDeleteConfirmationDialog(record['subject_name']); // Show confirmation dialog
                            },
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            if (isAttendanceDataVisible)
              Expanded(
                child: attendanceRecords.isEmpty || attendanceRecords.every((record) => record['status'] == null || record['status'] == '')
                    ? Center(child: Text('No records attendance found.', style: TextStyle(fontSize: 18, color: Colors.grey)))
                    : ListView.builder(
                  itemCount: attendanceRecords.length,
                  itemBuilder: (context, index) {
                    var record = attendanceRecords[index];

                    // Only show if there's a valid status
                    if (record['status'] == null || record['status'] == '') {
                      return Container(); // Skip rendering the tile if there's no status
                    }

                    return Card(
                      margin: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15.0),
                      ),
                      elevation: 4.0,
                      child: Row(
                        children: [
                          Container(
                            width: 8.0,
                            height: 90,
                            decoration: BoxDecoration(
                              color: Colors.deepPurple,
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(15),
                                bottomLeft: Radius.circular(15),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.all(12.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    record['subject_name'] ?? 'Loading...',
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                      color: Colors.black87,
                                    ),
                                  ),
                                  SizedBox(height: 6),
                                  Text(
                                    "Lecturer: ${record['lecturer_name'] ?? 'Loading...'}",
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.blueGrey,
                                    ),
                                  ),
                                  SizedBox(height: 6),
                                  Text(
                                    "Status: ${record['status'] ?? 'No Status'}",
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.green,
                                    ),
                                  ),
                                  SizedBox(height: 6),
                                  Text(
                                    "Date: ${record['attendance_date'] ?? 'No Date'}",
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.blueGrey,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }
}
