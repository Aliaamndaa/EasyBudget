import 'package:flutter/material.dart';
import 'package:smartattendface/screens/schedule/ClassSchedule.dart'; // Import ClassSchedule
import 'AttendanceRecord.dart';
import 'LoginPage.dart';
import 'StudentDetail.dart';
import 'SubjectRegistration.dart';

class HomeScreen extends StatefulWidget {
  final String email; // Accept email as a parameter

  const HomeScreen({Key? key, required this.email}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF10375C), // Set background color to blue
      appBar: AppBar(
        title: const Text(
          "Welcome to Attendface",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: Color(0xFF10375C),
        iconTheme: IconThemeData(
          color: Colors.white, // Set the back arrow to white
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white), // Set icon color to white
            onPressed: () {
              // Navigate to Sign In screen when user logs out
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => const LoginScreen()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: GridView(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            childAspectRatio: 1.3, // Adjusts button height and width
          ),
          children: [
            buildHomeButton(Icons.person, "Student Details", () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => StudentDetailsScreen(email: widget.email),
                ),
              );
            }),
            buildHomeButton(Icons.app_registration, "Subject Registration", () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SubjectRegistration()),
              );
            }),
            buildHomeButton(Icons.schedule, "Class Schedule", () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ClassSchedule()), // Correct class name
              );
            }),
            buildHomeButton(Icons.list_alt, "Attendance Records", () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AttendanceRecords()),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget buildHomeButton(IconData icon, String label, VoidCallback onPressed) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white, // Set button background to white
        borderRadius: BorderRadius.circular(16), // Rounded corners
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          foregroundColor: Color(0xFF10375C),
          backgroundColor: Colors.white, // Set text/icon color to dark blue
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16), // Rounded corners
          ),
          padding: const EdgeInsets.all(16),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 35, color: Color(0xFF10375C)), // Dark blue icon
            const SizedBox(height: 10),
            Text(
              label,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 17,
                color: Color(0xFF10375C), // Dark blue text
                fontWeight: FontWeight.normal,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
