import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class SubjectRegistration extends StatefulWidget {
  @override
  _SubjectRegistrationState createState() => _SubjectRegistrationState();
}

class _SubjectRegistrationState extends State<SubjectRegistration> {
  final List<String> semesters = ["Semester 1", "Semester 2"];
  String? selectedSemester;
  String? userYear;
  String? fullName;
  String? matricNumber;
  String? courseName; // Added courseName variable
  String? section;

  List<Map<String, dynamic>> availableSubjects = [];
  List<String> selectedSubjects = [];
  bool isLoadingSubjects = false;

  final String _getStudentDetailsUrl = 'http://192.168.0.18/get_student_details.php';
  final String _getAvailableSubjectsUrl = 'http://192.168.0.18/get_available_subject.php';
  final String _saveSelectedSubjectsUrl = 'http://192.168.0.18/save_selected_subject.php';

  @override
  void initState() {
    super.initState();
    _loadStudentData();
    _loadRegisteredSubjects(); // Load registered subjects after student data is fetched
  }

  Future<String?> _getUserEmail() async {
    final prefs = await SharedPreferences.getInstance();
    String? email = prefs.getString('user_email');
    return email;
  }

  Future<void> _loadStudentData() async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) {
        _showDialog("User email not found.");
        return;
      }

      final response = await http.post(
        Uri.parse(_getStudentDetailsUrl),
        body: {'email': userEmail.trim()},
      );

      // Debug the raw response
      print("Student Data Raw Response: ${response.body}");

      if (response.statusCode == 200) {
        try {
          final data = jsonDecode(response.body);
          if (data['success']) {
            setState(() {
              fullName = data['data']['fullName'];
              matricNumber = data['data']['matricNumber'];
              userYear = data['data']['year'];
              courseName = data['data']['course'];
              section = data['data']['section'];
            });
          } else {
            //_showDialog("Error: ${data['message']}");
            print("Error: ${data['message']}");
          }
        } catch (e) {
          _showDialog("Invalid JSON format: ${response.body}");
          print("JSON Error: $e");
        }
      } else {
        _showDialog("Failed to fetch student details. HTTP ${response.statusCode}");
      }
    } catch (e) {
      _showDialog("Error loading student data: $e");
      print("Exception: $e");
    }
  }

  Future<void> _loadRegisteredSubjects() async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) {
        _showDialog("User email not found.");
        return;
      }

      final response = await http.post(
        Uri.parse('http://192.168.0.18/get_registered_subjects.php'),
        body: {
          'email': userEmail.trim(),
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          setState(() {
            availableSubjects = availableSubjects.map((subject) {
              bool isRegistered = data['data'].contains(subject['subject']);
              return {
                ...subject,
                'isRegistered': isRegistered,
                'isSelected': isRegistered,
                'isDisabled': isRegistered,
              };
            }).toList();
          });
        } else {
          //_showDialog("Error: ${data['message']}");
          print("Error: ${data['message']}");
        }
      } else {
        _showDialog("Failed to fetch registered subjects.");
      }
    } catch (e) {
      _showDialog("An error occurred while loading registered subjects: $e");
    }
  }

  Future<void> _loadAvailableSubjects() async {
    setState(() {
      isLoadingSubjects = true;
    });

    try {
      String yearToSend = '';
      if (userYear == 'Year 1') yearToSend = '1';
      else if (userYear == 'Year 2') yearToSend = '2';
      else if (userYear == 'Year 3') yearToSend = '3';

      String semesterToSend = '';
      if (selectedSemester == 'Semester 1') {
        semesterToSend = 'sem 1';
      } else if (selectedSemester == 'Semester 2') {
        semesterToSend = 'sem 2';
      }

      if (courseName == null || courseName!.isEmpty) {
        _showDialog("Programme (course) is not loaded.");
        return;
      }

      final response = await http.post(
        Uri.parse(_getAvailableSubjectsUrl),
        body: {
          'year': yearToSend,
          'programme': courseName!,
          'semester': semesterToSend,
          'class': section!,
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          setState(() {
            availableSubjects = List<Map<String, dynamic>>.from(data['data']).map((subject) {
              return {
                ...subject,
                'isSelected': false,
                'isDisabled': subject['isRegistered'] ?? false,
              };
            }).toList();
          });
        } else {
          _showDialog("Error: ${data['message']}");
          //print("Error: ${data['message']}");
        }
      } else {
        _showDialog("Failed to fetch available subjects.");
      }
    } catch (e) {
      _showDialog("An error occurred while loading subjects: $e");
    } finally {
      setState(() {
        isLoadingSubjects = false;
      });
    }
  }

  Future<void> _saveSelectedSubjects() async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) {
        _showDialog("User email not found.");
        return;
      }

      List<String> selectedSubjectNames = availableSubjects
          .where((subject) => subject['isSelected'] == true)
          .map((subject) => subject['subject'] as String)
          .toList();

      final body = jsonEncode({
        'email': userEmail,
        'selectedSubjects': selectedSubjectNames,
      });

      print('Sending to server: $body');

      final response = await http.post(
        Uri.parse(_saveSelectedSubjectsUrl),
        headers: {"Content-Type": "application/json"},
        body: body,
      );

      // Error handling for invalid JSON response
      if (response.statusCode == 200) {
        try {
          final data = jsonDecode(response.body);
          if (data['success']) {
            _showDialog(data['message'], isSuccess: true);
          } else {
            _showDialog("Failed to register subjects: ${data['message']}");
          }
        } catch (e) {
          _showDialog("Error: Invalid JSON response.");
        }
      } else {
        _showDialog("Failed to register subjects.");
      }
    } catch (e) {
      _showDialog("An error occurred: $e");
    }
  }

  void _showDialog(String message, {bool isSuccess = false}) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(isSuccess ? 'Success' : 'Error'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF10375C),
        title: Text(
          'Subject Registration',
          style: TextStyle(fontFamily: 'Roboto', fontWeight: FontWeight.bold, color: Colors.white),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Scrollbar(
          thumbVisibility: true,
          child: SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  width: MediaQuery.of(context).size.width * 0.9,
                  child: Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Full Name: ${fullName ?? 'Loading...'}", style: TextStyle(fontSize: 16)),
                          SizedBox(height: 8),
                          Text("Matric Number: ${matricNumber ?? 'Loading...'}", style: TextStyle(fontSize: 16)),
                          SizedBox(height: 8),
                          Text("Year: ${userYear ?? 'Loading...'}", style: TextStyle(fontSize: 16)),
                          SizedBox(height: 8),
                          Text("Course: ${courseName ?? 'Loading...'}", style: TextStyle(fontSize: 16)),
                          SizedBox(height: 8),
                          Text("Section: ${section ?? 'Loading...'}", style: TextStyle(fontSize: 16)),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  decoration: BoxDecoration(
                    color: Colors.deepPurple.shade50,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 4))],
                  ),
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: DropdownButton<String>(
                    hint: Text("Select Semester", style: TextStyle(fontSize: 16, color: Colors.deepPurple.shade700)),
                    value: selectedSemester,
                    onChanged: (value) {
                      setState(() {
                        selectedSemester = value;
                        _loadAvailableSubjects();
                      });
                    },
                    isExpanded: true,
                    icon: Icon(Icons.arrow_drop_down, color: Colors.deepPurple.shade700),
                    items: ['Semester 1', 'Semester 2'].map((semester) {
                      return DropdownMenuItem(
                        value: semester,
                        child: Text(semester, style: TextStyle(fontSize: 16, color: Colors.deepPurple.shade700)),
                      );
                    }).toList(),
                  ),
                ),
                SizedBox(height: 20),
                Text("Available Subjects:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.w500)),
                Divider(),
                Container(
                  height: 400,
                  child: availableSubjects.isEmpty
                      ? Center(child: Text("No subjects available for the selected semester."))
                      : ListView.builder(
                    itemCount: availableSubjects.length,
                    itemBuilder: (context, index) {
                      final subject = availableSubjects[index];
                      return Card(
                        margin: EdgeInsets.symmetric(vertical: 8),
                        elevation: 2,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        child: ListTile(
                          title: Text('${subject['subject']} - ${subject['LectName']}', style: TextStyle(fontSize: 16)),
                          trailing: Checkbox(
                            value: subject['isSelected'] ?? false,
                            onChanged: subject['isDisabled'] == true ? null : (bool? value) {
                              setState(() {
                                subject['isSelected'] = value;
                              });
                            },
                          ),
                        ),
                      );
                    },
                  ),
                ),
                SizedBox(height: 40),
                ElevatedButton(
                  onPressed: _saveSelectedSubjects,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Color(0xFF10375C),
                    padding: EdgeInsets.symmetric(vertical: 16, horizontal: 32),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  ),
                  child: Text(
                    'Register Subjects',
                    style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
