import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

class StudentDetailsScreen extends StatefulWidget {
  final String email;

  const StudentDetailsScreen({Key? key, required this.email}) : super(key: key);

  @override
  _StudentDetailsScreenState createState() => _StudentDetailsScreenState();
}

class _StudentDetailsScreenState extends State<StudentDetailsScreen> {
  final _formKey = GlobalKey<FormState>();

  // Controllers for input fields
  final TextEditingController _fullNameController = TextEditingController();
  final TextEditingController _ICNumController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _matricNumberController = TextEditingController();
  final TextEditingController _facultyController = TextEditingController();

  // Dropdown selection fields
  String? selectedYear;
  String? selectedSection;
  String? selectedGender;
  String? selectedCourse;

  String? _profileImageUrl; // Store the profile image URL
  File? _profileImageFile; // For captured or uploaded image
  bool _isExistingUser = false; // Flag to check if user is existing

  @override
  void initState() {
    super.initState();
    _fetchStudentDetails();
  }

  Future<void> _fetchStudentDetails() async {
    try {
      final uri = Uri.parse('http://192.168.0.18/get_student_details.php');
      final response = await http.post(uri, body: {'email': widget.email});

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);

        if (responseData['success']) {
          final studentDetails = responseData['data'];

          setState(() {
            _fullNameController.text = studentDetails['fullName'];
            _ICNumController.text = studentDetails['ICNum'];
            _phoneNumberController.text = studentDetails['phoneNumber'];
            _matricNumberController.text = studentDetails['matricNumber'];
            _facultyController.text = studentDetails['faculty'];
            selectedGender = studentDetails['gender'];
            selectedYear = studentDetails['year'];
            selectedSection = studentDetails['section'];
            selectedCourse = studentDetails['course'];
            _profileImageUrl = studentDetails['profile_image'];
            _isExistingUser = true;
          });
        } else {
          setState(() {
            _isExistingUser = false;
          });
          _showAlertDialog('Error', responseData['message']);
        }
      } else {
        throw Exception('Failed to load student details');
      }
    } catch (error) {
      _showAlertDialog('Error', 'Failed to load student details');
    }
  }

  Future<void> _updateStudentDetails() async {
    try {
      final uri = Uri.parse('http://192.168.0.18/update_student_details.php');
      final response = await http.post(uri, body: {
        'email': widget.email,
        'year': selectedYear ?? '',
        'section': selectedSection ?? '',
        'course': selectedCourse ?? '',
      });

      final responseData = jsonDecode(response.body);

      if (responseData['success']) {
        _showAlertDialog('Success', 'Student details updated successfully');
      } else {
        _showAlertDialog('Error', 'Error: ${responseData['message']}');
      }
    } catch (error) {
      _showAlertDialog('Error', 'Failed to update details: $error');
    }
  }

  Future<void> _saveStudentDetails() async {
    try {
      final uri = Uri.parse('http://192.168.0.18/save_student_details.php');
      final request = http.MultipartRequest('POST', uri);

      request.fields['email'] = widget.email;
      request.fields['fullName'] = _fullNameController.text;
      request.fields['ICNum'] = _ICNumController.text;
      request.fields['phoneNumber'] = _phoneNumberController.text;
      request.fields['matricNumber'] = _matricNumberController.text;
      request.fields['faculty'] = _facultyController.text;
      request.fields['gender'] = selectedGender ?? '';
      request.fields['year'] = selectedYear ?? '';
      request.fields['section'] = selectedSection ?? '';
      request.fields['course'] = selectedCourse ?? '';

      if (_profileImageFile != null) {
        // Set the image file name as the matric number
        final fileName = '${_matricNumberController.text}_profile.jpg';
        request.files.add(await http.MultipartFile.fromPath(
          'profileImage',
          _profileImageFile!.path,
          filename: fileName, // Set custom file name
        ));
      }

      final response = await request.send();
      final responseBody = await response.stream.bytesToString();

      if (response.statusCode == 200) {
        final responseData = jsonDecode(responseBody);
        if (responseData['success']) {
          _showAlertDialog('Success', responseData['message']);
        } else {
          _showAlertDialog('Error', 'Error: ${responseData['message']}');
        }
      } else {
        throw Exception('Failed to save details: ${response.statusCode}');
      }
    } catch (error) {
      _showAlertDialog('Error', 'Failed to save details: $error');
    }
  }

  void _showAlertDialog(String title, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _profileImageFile = File(pickedFile.path);
        _profileImageUrl = null; // Clear the network image URL if a new image is chosen
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No image selected')),
      );
    }
  }


  Future<void> _captureImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.camera);

    if (pickedFile != null) {
      setState(() {
        _profileImageFile = File(pickedFile.path);
        _profileImageUrl = null; // Clear the network image URL if a new image is captured
      });
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No image captured')),
      );
    }
  }


  Widget _buildProfileImage() {
    return Column(
      children: [
        CircleAvatar(
          radius: 70,
          backgroundColor: Colors.grey[200],
          backgroundImage: _profileImageFile != null
              ? FileImage(_profileImageFile!) as ImageProvider
              : (_profileImageUrl != null && _profileImageUrl!.isNotEmpty
              ? NetworkImage(_profileImageUrl!)
              : AssetImage('assets/images/profile_placeholder.png')),
          onBackgroundImageError: (error, stackTrace) {
            print('Error loading image: $error');
          },
        ),
        SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            IconButton(
              icon: Icon(Icons.camera_alt, color: Colors.deepPurple),
              onPressed: _captureImage,
            ),
            IconButton(
              icon: Icon(Icons.photo_library, color: Colors.deepPurple),
              onPressed: _pickImage,
            ),
          ],
        ),
        SizedBox(height: 24),
      ],
    );
  }



  Widget _buildDropdown(String label, String? value, List<String> items, Function(String?) onChanged) {
    return DropdownButtonFormField<String>(
      value: value,
      items: items
          .map((item) => DropdownMenuItem(value: item, child: Text(item)))
          .toList(),
      onChanged: onChanged,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.blueGrey),
        contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
        filled: true,
        fillColor: Colors.grey[200], // Updated fill color
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF10375C),
        title: Text(
          "Student Details",
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              _buildProfileImage(),
              TextFormField(
                controller: _fullNameController,
                decoration: InputDecoration(
                  labelText: "Full Name",
                  labelStyle: TextStyle(color: Colors.blueGrey),
                  contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  filled: true,
                  fillColor: Colors.grey[200],
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
                readOnly: _isExistingUser,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _ICNumController,
                decoration: InputDecoration(
                  labelText: "IC Number",
                  labelStyle: TextStyle(color: Colors.blueGrey),
                  contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  filled: true,
                  fillColor: Colors.grey[200],
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
                readOnly: _isExistingUser,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _phoneNumberController,
                decoration: InputDecoration(
                  labelText: "Phone Number",
                  labelStyle: TextStyle(color: Colors.blueGrey),
                  contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  filled: true,
                  fillColor: Colors.grey[200],
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
                readOnly: _isExistingUser,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _matricNumberController,
                decoration: InputDecoration(
                  labelText: "Matric Number",
                  labelStyle: TextStyle(color: Colors.blueGrey),
                  contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  filled: true,
                  fillColor: Colors.grey[200],
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
                readOnly: _isExistingUser,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: _facultyController,
                decoration: InputDecoration(
                  labelText: "Faculty",
                  labelStyle: TextStyle(color: Colors.blueGrey),
                  contentPadding: EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                  filled: true,
                  fillColor: Colors.grey[200],
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                ),
                readOnly: _isExistingUser,
              ),
              SizedBox(height: 16),
              _buildDropdown("Gender", selectedGender, ['Male', 'Female'], (value) {
                setState(() {
                  selectedGender = value;
                });
              }),
              SizedBox(height: 16),
              _buildDropdown("Year", selectedYear, ['Year 1', 'Year 2', 'Year 3'], (value) {
                setState(() {
                  selectedYear = value;
                });
              }),

              SizedBox(height: 16),
              _buildDropdown("Section/Group", selectedSection, ['S1G1', 'S1G2', 'S2G1', 'S2G2'], (value) {
                setState(() {
                  selectedSection = value;
                });
              }),
              SizedBox(height: 16),
              _buildDropdown("Course", selectedCourse, ['BITS', 'BITZ', 'BITD'], (value) {
                setState(() {
                  selectedCourse = value;
                });
              }),
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    if (_isExistingUser) {
                      _updateStudentDetails();
                    } else {
                      _saveStudentDetails();
                    }
                  }
                },
                child: Text(
                  _isExistingUser ? "Update Details" : "Save Details",
                  style: TextStyle(
                    color: Colors.white,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFF10375C),
                  padding: EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
