import 'package:flutter/material.dart';

class SUBJECT_BITZ extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'BITZ Subject Course',
          style: TextStyle(
            color: Colors.white, // Set title color to white for visibility
            fontSize: 20,
          ),
        ),
        backgroundColor: Color(0xFF10375C), // Set your desired app bar color
        iconTheme: const IconThemeData(
          color: Colors.white, // Set the back arrow to white
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Heading Text
            const Text(
              'Please refer to the following subjects and their lecturers:',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black, // Black text for visibility
              ),
            ),
            const SizedBox(height: 20),

            // List of subjects
            Expanded(
              child: ListView(
                children: [
                  _buildSubjectItem('BITM 1133', 'Multimedia System', 'DR SARNI'),
                  _buildSubjectItem('BITI 1213', 'Linear Algebra and Discrete Mathematics', 'DR RIZUAN'),
                  _buildSubjectItem('BITP 1113', 'Programming Technique', 'TS MASHANUM'),
                  _buildSubjectItem('BITS 1123', 'Computer Organization and Architecture', 'ZAKIAH'),
                  _buildSubjectItem('BLLW 1142', 'Bahasa Inggeris untuk Tujuan Akademik', 'TAHKIM'),
                  _buildSubjectItem('BLHW 1762', 'Falsafah dan Isu Semasa', 'DR SAZELIN'),
                  _buildSubjectItem('BITI 1203', 'Fundamental Mathematics', 'PM ASMALA'),
                  _buildSubjectItem('BITI 2233', 'Statistics and Probability', 'PM ZERATUL'),
                  _buildSubjectItem('BITS 1213', 'Operating System', 'DR SHEIKH'),
                  _buildSubjectItem('BITS 2343', 'Computer Network', 'DR NAZRUL'),
                  _buildSubjectItem('BITI 1113', 'Artificial Intelligence', 'DR YAAKOB'),
                  _buildSubjectItem('BLLW 2152', 'Academic Writing', 'NORAINI'),
                  _buildSubjectItem('BITS 3353', 'Network Security Administration and Management', 'DR WARUSIA'),
                  _buildSubjectItem('BITS 3463', 'Applied Cryptography & Information Theory', 'PM AZMAN ABU'),
                  _buildSubjectItem('BITS 3453', 'Malware Analysis & Digital Investigation', 'DR ZAKI'),
                  _buildSubjectItem('BITS 3363', 'Network Security Project Management', 'DR ZAHEERA'),
                  _buildSubjectItem('BLLW 3162', 'English for Professional Interaction', 'TEH ZANARIAH'),
                  _buildSubjectItem('BLHC 4032', 'Pemikiran Kritis & Kreatif', 'DR FAUZI'),
                  _buildSubjectItem('BLHW 2772', 'Penghayatan Etika & Peradaban', 'DR RAZUAN'),
                  _buildSubjectItem('BTMW 4012', 'Technology Entrepreneurship', 'AMIRUL'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper method to build the subject item widgets
  Widget _buildSubjectItem(String code, String name, String lecturer) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        title: Text(
          '$code - $name',
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black,
          ),
        ),
        subtitle: Text(
          'Lecturer: $lecturer',
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.normal,
            color: Colors.black,
          ),
        ),
        onTap: () {
          // Handle subject selection (e.g., navigate to a detailed page for that subject)
          print('Selected: $name');
        },
      ),
    );
  }
}
