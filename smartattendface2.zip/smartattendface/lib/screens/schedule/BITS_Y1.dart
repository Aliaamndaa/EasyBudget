import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'view_schedule.dart';

class BITS_Y1page extends StatefulWidget {
  const BITS_Y1page({super.key});

  @override
  _BITS_Y1pageState createState() => _BITS_Y1pageState();
}

class _BITS_Y1pageState extends State<BITS_Y1page> {
  String? section;

  bool isLoading = true;
  String errorMessage = '';

  @override
  void initState() {
    super.initState();
    _loadStudentData();
  }

  // Load user email
  Future<String?> _getUserEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_email');
  }

  // Load student details
  Future<void> _loadStudentData() async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) return;

      final response = await http.post(
        Uri.parse('http://192.168.0.18/get_student_details.php'),
        body: {'email': userEmail.trim()},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          setState(() {
            section = data['data']['section']; // Extract only section from the data
            isLoading = false;
          });
        }
      }
    } catch (e) {
      setState(() {
        errorMessage = "Error: $e";
        isLoading = false;
      });
    }
  }

  // Build class card (for demonstration)
  Widget _buildClassCard(String className, BuildContext context, String classSection) {
    // Disable button if the section doesn't match the student section
    bool isButtonEnabled = section == classSection;

    return Card(
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              className,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: isButtonEnabled
                  ? () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ViewSchedule(
                      course: 'BITS',  // Replace with dynamic course name if necessary
                      year: 'Year 1',  // Adjust this accordingly
                      email: '',       // Provide the user's email if needed
                    ),
                  ),
                );
              }
                  : null, // Button is disabled if the section doesn't match
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF10375C),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('View Schedule'),
            ),
            if (!isButtonEnabled)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text(
                  'You cannot view the schedule for this section.',
                  style: TextStyle(color: Colors.red, fontSize: 14),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'BITS - Year 1',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Color(0xFF10375C),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Display loading or error message
              isLoading
                  ? Center(child: CircularProgressIndicator())
                  : errorMessage.isNotEmpty
                  ? Center(child: Text(errorMessage))
                  : const SizedBox.shrink(), // No student details are shown

              const SizedBox(height: 20), // Space between student details and class cards

              // Class Sections (only those that match the student section will be enabled)
              _buildClassCard('S1G1', context, 'S1G1'),
              const SizedBox(height: 20), // Space between cards

              _buildClassCard('S1G2', context, 'S1G2'),
              const SizedBox(height: 20), // Space between cards

              _buildClassCard('S2G1', context, 'S2G1'),
              const SizedBox(height: 20), // Space between cards

              _buildClassCard('S2G2', context, 'S2G2'),
              const SizedBox(height: 20), // Space between cards
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.white,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildBottomNavItem(Icons.schedule, "Schedule", Colors.purple),
            //_buildBottomNavItem(Icons.subject, "Subject", Colors.purple),
          ],
        ),
      ),
    );
  }

  // Helper method to build bottom navigation items
  Widget _buildBottomNavItem(IconData icon, String label, Color color) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: color,
        ),
        const SizedBox(height: 4), // Space between icon and text
        Text(
          label,
          style: TextStyle(color: color),
        ),
      ],
    );
  }
}
