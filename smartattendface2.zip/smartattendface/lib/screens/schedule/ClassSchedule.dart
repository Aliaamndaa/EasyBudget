import 'package:flutter/material.dart';
import 'package:smartattendface/screens/HomeScreen.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

// BITS Imports
import 'BITS_Y1.dart';
import 'BITS_Y2.dart';
import 'BITS_Y3.dart';
// BITZ Imports
import 'BITZ_Y1.dart';
import 'BITZ_Y2.dart';
import 'BITZ_Y3.dart';
// BITD Imports
import 'BITD_Y1.dart';
import 'BITD_Y2.dart';
import 'BITD_Y3.dart';
// LIST_SUBJECT Import
import 'LIST_SUBJECT.dart';

void main() {
  runApp(const ClassSchedule());
}

class ClassSchedule extends StatefulWidget {
  const ClassSchedule({Key? key}) : super(key: key);

  @override
  _ClassScheduleState createState() => _ClassScheduleState();
}

class _ClassScheduleState extends State<ClassSchedule> {
  String? selectedCourse;
  String? selectedYear;
  String? errorMessage;
  List<String> courses = ['BITS', 'BITZ', 'BITD'];
  int currentIndex = 0;
  String? userYear;
  String? course;

  final List<String> years = ['Year 1', 'Year 2', 'Year 3'];

  @override
  void initState() {
    super.initState();
    selectedCourse = null;
    selectedYear = null;
    _loadStudentData();
  }

  Future<String?> _getUserEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_email');
  }

  Future<void> _loadStudentData() async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) return;

      final response = await http.post(
        Uri.parse('http://192.168.0.18/get_student_details.php'),
        body: {'email': userEmail.trim()},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          setState(() {
            userYear = data['data']['year'];
            course = data['data']['course'];
          });
        } else {
          setState(() {
            userYear = null;
            course = null;
          });
        }
      }
    } catch (e) {
      _showSnackBar("Error: $e");
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void resetSelection() {
    setState(() {
      selectedCourse = null;
      selectedYear = null;
    });
  }

  void navigateToCourseScreen() {
    if (selectedCourse != null && selectedYear != null) {
      if (selectedCourse == course && selectedYear == userYear) {
        String routeName = '${selectedCourse}_${selectedYear?.replaceAll(' ', '_')}Page';

        switch (routeName) {
          case 'BITS_Year_1Page':
            Navigator.push(context, MaterialPageRoute(builder: (context) => BITS_Y1page()))
                .then((_) => resetSelection());
            break;
          case 'BITS_Year_2Page':
            Navigator.push(context, MaterialPageRoute(builder: (context) => BITS_Y2page()))
                .then((_) => resetSelection());
            break;
          case 'BITS_Year_3Page':
            Navigator.push(context, MaterialPageRoute(builder: (context) => BITS_Y3page()))
                .then((_) => resetSelection());
            break;
          case 'BITZ_Year_1Page':
            Navigator.push(context, MaterialPageRoute(builder: (context) => BITZ_Y1page()))
                .then((_) => resetSelection());
            break;
          case 'BITZ_Year_2Page':
            Navigator.push(context, MaterialPageRoute(builder: (context) => BITZ_Y2page()))
                .then((_) => resetSelection());
            break;
          case 'BITZ_Year_3Page':
            Navigator.push(context, MaterialPageRoute(builder: (context) => BITZ_Y3page()))
                .then((_) => resetSelection());
            break;
          case 'BITD_Year_1Page':
            Navigator.push(context, MaterialPageRoute(builder: (context) => BITD_Y1page()))
                .then((_) => resetSelection());
            break;
          case 'BITD_Year_2Page':
            Navigator.push(context, MaterialPageRoute(builder: (context) => BITD_Y2page()))
                .then((_) => resetSelection());
            break;
          case 'BITD_Year_3Page':
            Navigator.push(context, MaterialPageRoute(builder: (context) => BITD_Y3page()))
                .then((_) => resetSelection());
            break;
          default:
            _showSnackBar('Invalid selection!');
            break;
        }
      } else {
        setState(() {
          errorMessage = 'Your selection does not match your profile.';
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF10375C),
        title: Text("Class Schedule", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context); // Going back to previous page and ensuring state reload
            _loadStudentData(); // Reload student data when coming back
          },
        ),
      ),
      body: currentIndex == 0 ? buildScheduleScreen() : LIST_SUBJECT(),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: currentIndex,
        onTap: (index) {
          setState(() {
            currentIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.schedule), label: 'Schedule'),
          BottomNavigationBarItem(icon: Icon(Icons.subject), label: 'Subjects'),
        ],
      ),
    );
  }

  Widget buildScheduleScreen() {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        children: [
          Image.asset('assets/images/ftmk.jpg', width: 150, height: 150),
          const SizedBox(height: 5),
          const Text('SEM 1 2024/2025', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          const Text('Please choose a course for schedule', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 20),
          DropdownButton<String>(
            value: selectedCourse,
            hint: const Text("Select Course"),
            isExpanded: true,
            onChanged: (value) {
              setState(() {
                selectedCourse = value;
                selectedYear = null; // Reset year selection when course is changed
              });
            },
            items: courses.map((course) {
              return DropdownMenuItem(value: course, child: Text(course));
            }).toList(),
          ),
          const SizedBox(height: 20),
          if (selectedCourse != null)
            DropdownButton<String>(
              value: selectedYear,
              hint: const Text("Select Year"),
              isExpanded: true,
              onChanged: (year) {
                setState(() {
                  selectedYear = year;
                });
                navigateToCourseScreen();
              },
              items: years.map((year) {
                return DropdownMenuItem(value: year, child: Text(year));
              }).toList(),
            ),
          if (errorMessage != null)
            Text(errorMessage!, style: TextStyle(color: Colors.red)),
        ],
      ),
    );
  }
}
