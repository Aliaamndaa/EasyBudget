import 'package:flutter/material.dart';

// Import subject pages
import 'SUBJECT_BITS.dart';
import 'SUBJECT_BITD.dart';
import 'SUBJECT_BITZ.dart';


class LIST_SUBJECT extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final List<String> courses = ['BITS', 'BITZ', 'BITD']; // Reordered list
    final List<IconData> courseIcons = [
      Icons.computer, // Icon for BITS
      Icons.security, // Icon for BITZ
      Icons.storage,  // Icon for BITD
    ];

    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Add Image at the top
          Center(
            child: Image.asset(
              'assets/images/ftmk.jpg', // Path to your image
              width: 150, // Image width
              height: 150, // Image height
            ),
          ),
          const SizedBox(height: 10),

          // Add Semester Text below the Image
          const Center(
            child: Text(
              'SEM 1 2024/2025',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 20),

          // Select Course Text
          const Text(
            'Select Course',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 20),

          // Grid of Courses
          GridView.builder(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
            ),
            itemCount: courses.length,
            itemBuilder: (context, index) {
              return CourseCard(
                courseName: courses[index],
                icon: courseIcons[index], // Use reordered icon
                onTap: () {
                  // Navigate to the corresponding page based on the course
                  if (courses[index] == 'BITS') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SUBJECT_BITS()),
                    );
                  } else if (courses[index] == 'BITD') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SUBJECT_BITD()),
                    );
                  } else if (courses[index] == 'BITZ') {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SUBJECT_BITZ()),
                    );
                  }
                },
              );
            },
          ),
        ],
      ),
    );
  }
}

class CourseCard extends StatelessWidget {
  final String courseName;
  final IconData icon;
  final VoidCallback onTap; // Add onTap callback

  const CourseCard({Key? key, required this.courseName, required this.icon, required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap, // Trigger the onTap action
      child: Card(
        elevation: 5,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        color: Colors.black, // Change this to your desired color
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon, // Dynamic icon based on course
              size: 40,
              color: Colors.white,
            ),
            const SizedBox(height: 10),
            Text(
              courseName,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 15,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
