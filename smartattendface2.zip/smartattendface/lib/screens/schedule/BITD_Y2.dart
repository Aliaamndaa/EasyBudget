import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'view_schedule.dart';

class BITD_Y2page extends StatefulWidget {
  const BITD_Y2page({super.key});

  @override
  _BITD_Y2pageState createState() => _BITD_Y2pageState();
}

class _BITD_Y2pageState extends State<BITD_Y2page> {
  String? section;
  bool isLoading = true;
  String errorMessage = '';

  @override
  void initState() {
    super.initState();
    _loadStudentData();
  }

  Future<String?> _getUserEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_email');
  }

  Future<void> _loadStudentData() async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null) return;

      final response = await http.post(
        Uri.parse('http://192.168.0.18/get_student_details.php'),
        body: {'email': userEmail.trim()},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          setState(() {
            section = data['data']['section'];
            isLoading = false;
          });
        }
      }
    } catch (e) {
      setState(() {
        errorMessage = "Error: $e";
        isLoading = false;
      });
    }
  }

  Widget _buildClassCard(String className, BuildContext context, String classSection) {
    bool isButtonEnabled = section == classSection;

    return Card(
      color: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              className,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: isButtonEnabled
                  ? () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ViewSchedule(
                      course: 'BITD',
                      year: 'Year 2',
                      email: '',
                    ),
                  ),
                );
              }
                  : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFF10375C),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('View Schedule'),
            ),
            if (!isButtonEnabled)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text(
                  'You cannot view the schedule for this section.',
                  style: TextStyle(color: Colors.red, fontSize: 14),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'BITD - Year 2',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Color(0xFF10375C),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              isLoading
                  ? Center(child: CircularProgressIndicator())
                  : errorMessage.isNotEmpty
                  ? Center(child: Text(errorMessage))
                  : const SizedBox.shrink(),

              const SizedBox(height: 20),

              _buildClassCard('S1G1', context, 'S1G1'),
              const SizedBox(height: 20),

              _buildClassCard('S1G2', context, 'S1G2'),
              const SizedBox(height: 20),

              _buildClassCard('S2G1', context, 'S2G1'),
              const SizedBox(height: 20),

              _buildClassCard('S2G2', context, 'S2G2'),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        color: Colors.white,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildBottomNavItem(Icons.schedule, "Schedule", Colors.purple),
            //_buildBottomNavItem(Icons.subject, "Subject", Colors.purple),
          ],
        ),
      ),
    );
  }

  Widget _buildBottomNavItem(IconData icon, String label, Color color) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: color,
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: TextStyle(color: color),
        ),
      ],
    );
  }
}
