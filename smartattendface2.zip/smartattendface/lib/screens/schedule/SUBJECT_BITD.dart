import 'package:flutter/material.dart';

class SUBJECT_BITD extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BITD Subject Course'),
        backgroundColor: Color(0xFF10375C),
        iconTheme: const IconThemeData(
          color: Colors.white, // Set the back arrow to white
        ),// Dark background to make white text visible
        titleTextStyle: const TextStyle(
          color: Colors.white, // White font color for the title
          fontSize: 20,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Heading Text
            const Text(
              'Please refer to the following subjects and their lecturers:',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black, // Set the font color to white
              ),
            ),
            const SizedBox(height: 20),

            // List of subjects
            Expanded(
              child: ListView(
                children: [
                  _buildSubjectItem('BITI 1213', 'Linear Algebra and Discrete Mathematics', 'DR NGO'),
                  _buildSubjectItem('BITM 1113', 'Multimedia System', 'DR CHE KU'),
                  _buildSubjectItem('BITP 1113', 'Programming Technique', 'TS MASLITA'),
                  _buildSubjectItem('BITS 1123', 'Computer Organization and Architecture', 'DR ASLINDA'),
                  _buildSubjectItem('BLLW 1142', 'Bahasa Inggeris untuk Tujuan Akademik', 'DR LEE MEI PH’NG'),
                  _buildSubjectItem('BLHW 1142', 'Falsafah & Isu Semasa', 'PM DR SAZELIN'),
                  _buildSubjectItem('BITI 1203', 'Fundamental Mathematics', 'PM ASMALA'),
                  _buildSubjectItem('BITI 2233', 'Statistics and Probability', 'PM SAKINAH'),
                  _buildSubjectItem('BITP 2313', 'Database Design', 'DR ATIKAH'),
                  _buildSubjectItem('BITM 2313', 'Human Computer Interaction', 'TS SYARIFFANOR'),
                  _buildSubjectItem('BITP 2303', 'Database Programming', 'DR ASHIKIN'),
                  _buildSubjectItem('BITS 1213', 'Operating System', 'NURHASHIKIN'),
                  _buildSubjectItem('BLHC 4032', 'Pemikiran Kritis & Kreatif', 'DR FAUZI'),
                  _buildSubjectItem('BITP 3483', 'Geographical Information System', 'DR SAFIZA'),
                  _buildSubjectItem('BITP 3433', 'IT and Database Security', 'PM NURUL'),
                  _buildSubjectItem('BITP 3223', 'Software Project Management', 'PROF KHANAPI'),
                  _buildSubjectItem('BITM 2113', 'Web Application Development', 'EN FAIQ'),
                  _buildSubjectItem('BITP 3363', 'Data Warehousing and Business Intelligence', 'DR IZRIN'),
                  _buildSubjectItem('BLLW 3162', 'English for Professional Interaction', 'ANISAH KASIM'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper method to build the subject item widgets
  Widget _buildSubjectItem(String code, String name, String lecturer) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        title: Text(
          '$code - $name',
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black, // Set the font color to white
          ),
        ),
        subtitle: Text(
          'Lecturer: $lecturer',
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.normal,
            color: Colors.black, // Set the font color to white
          ),
        ),
        onTap: () {
          // Handle subject selection (e.g., navigate to a detailed page for that subject)
          print('Selected: $name');
        },
      ),
    );
  }
}
