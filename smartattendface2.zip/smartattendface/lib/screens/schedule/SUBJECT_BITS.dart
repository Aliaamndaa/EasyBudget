import 'package:flutter/material.dart';

class SUBJECT_BITS extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('BITS Subject Course'),
        backgroundColor: Color(0xFF10375C),
        iconTheme: const IconThemeData(
          color: Colors.white, // Set the back arrow to white
        ),// Set your desired app bar color
        titleTextStyle: const TextStyle(
          color: Colors.white, // Set title color to white for visibility
          fontSize: 20,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Heading Text
            const Text(
              'Please refer to the following subjects and their lecturers:',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 20),

            // List of subjects
            Expanded(
              child: ListView(
                children: [
                  _buildSubjectItem('BITM 1133', 'Multimedia System', 'DR MAHFUZAH'),
                  _buildSubjectItem('BITI 1213', 'Linear Algebra and Discrete Mathematics', 'DR YOGAN'),
                  _buildSubjectItem('BITP 1113', 'Programming Technique', 'DR ZAHRIAH'),
                  _buildSubjectItem('BITS 1123', 'Computer Organization and Architecture', 'DR NAJWAN'),
                  _buildSubjectItem('BLLW 1142', 'Bahasa Inggeris untuk Tujuan Akademik', 'ANISAH KASIM'),
                  _buildSubjectItem('BLHW 1762', 'Falsafah dan Isu Semasa', 'DR AZILAH'),
                  _buildSubjectItem('BITI 1203', 'Fundamental Mathematics', 'PM ASMALA'),
                  _buildSubjectItem('BITP 3113', 'Object Oriented Programming', 'PM SANUSI'),
                  _buildSubjectItem('BITP 2113', 'Algorithm Analysis', 'DR INTAN'),
                  _buildSubjectItem('BITI 2233', 'Statistics and Probability', 'DR SEK'),
                  _buildSubjectItem('BITS 1213', 'Operating System', 'RADZI'),
                  _buildSubjectItem('BITP 2313', 'Database Design', 'DR SYAHIDA'),
                  _buildSubjectItem('BLHC 4032', 'Pemikiran Kritis & Kreatif', 'DR FAUZI'),
                  _buildSubjectItem('BITM 2313', 'Human Computer Interaction', 'PROF FAAIZAH'),
                  _buildSubjectItem('BITM 2113', 'Web Application Development', 'DR KHALID'),
                  _buildSubjectItem('BITP 3453', 'Mobile Application Development', 'DR NOOREZZAM'),
                  _buildSubjectItem('BITP 3453', 'Mobile Application Development', 'DR HARIZ'),
                  _buildSubjectItem('BITP 3223', 'Software Project Management', 'DR KARIM '),
                  _buildSubjectItem('BITP 3223', 'Software Project Management', 'DR RAJA RINA '),
                  _buildSubjectItem('BITS 3423', 'Information Technology Security', 'DR RAIHANA'),
                  _buildSubjectItem('BLLW 3162', 'English for Professional Interaction', 'NADIAH'),
                  _buildSubjectItem('BLLW 3162', 'English for Professional Interaction', 'TEH ZANARIAH'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Helper method to build the subject item widgets
  Widget _buildSubjectItem(String code, String name, String lecturer) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 8.0),
      elevation: 5,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        title: Text(
          '$code - $name',
          style: const TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: Colors.black, // Set the font color to white
          ),
        ),
        subtitle: Text(
          'Lecturer: $lecturer',
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.normal,
            color: Colors.black,
          ),
        ),
        onTap: () {
          // Handle subject selection (e.g., navigate to a detailed page for that subject)
          print('Selected: $name');
        },
      ),
    );
  }
}
