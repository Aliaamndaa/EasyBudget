import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class ViewSchedule extends StatefulWidget {
  final String course;
  final String year;
  final String email;

  const ViewSchedule({
    super.key,
    required this.course,
    required this.year,
    required this.email,
  });

  @override
  _ViewScheduleState createState() => _ViewScheduleState();
}

class _ViewScheduleState extends State<ViewSchedule> {
  List<dynamic> classDetails = [];
  bool isLoading = true;
  String errorMessage = '';

  void _takeAttendance(int scheduleId) async {
    try {
      final response = await http
          .post(
        Uri.parse('http://10.0.2.2:5000/start_recognition'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: jsonEncode({'schedule_id': scheduleId}),
      )
          .timeout(
        const Duration(seconds: 20),
        onTimeout: () {
          throw Exception('Recognition process timed out after 20 seconds.');
        },
      );

      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          print("Attendance recorded for: ${data['recognized_student']}, Schedule ID: $scheduleId");
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Attendance Taken'),
              content: Text('Successfully took attendance.'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text('OK'),
                ),
              ],
            ),
          );
        } else {
          print("Error: ${data['message']}");
          showDialog(
            context: context,
            builder: (context) => AlertDialog(
              title: Text('Attendance Failed'),
              content: Text('Error: ${data['message']}'),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: Text('OK'),
                ),
              ],
            ),
          );
        }
      } else {
        print("Failed to connect to face recognition service.");
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text('Connection Failed'),
            content: Text('Failed to connect to the face recognition service.'),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: Text('OK'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      print("Error: $e");
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text('Error'),
          content: Text('An error occurred: $e'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: Text('OK'),
            ),
          ],
        ),
      );
    }
  }


  @override
  void initState() {
    super.initState();
    _fetchClassSchedule();
  }

  // Show SnackBar
  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  // Fetch user email
  Future<String?> _getUserEmail() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('user_email');
  }

  // Fetch class schedule
  Future<void> _fetchClassSchedule() async {
    try {
      String? userEmail = await _getUserEmail();
      if (userEmail == null || userEmail.isEmpty) {
        _showSnackBar("User email not found.");
        return;
      }

      final response = await http.post(
        Uri.parse('http://192.168.0.18/get_student_schedule.php'),
        headers: {
          'Content-Type': 'application/json', // Use 'application/json'
        },
        body: jsonEncode({'email': userEmail.trim()}), // Send JSON encoded data
      );

      print('Response Status: ${response.statusCode}');
      print('Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success']) {
          setState(() {
            classDetails = data['schedule'] ?? [];
            print('Class Details: $classDetails');
            isLoading = false;
          });
        } else {
          _showSnackBar(data['message'] ?? "No classes found.");
        }
      } else {
        _showSnackBar("Failed to load data. Status code: ${response.statusCode}");
      }
    } catch (e) {
      _showSnackBar("Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '${widget.course} - ${widget.year}',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Color(0xFF10375C),
        iconTheme: IconThemeData(
          color: Colors.white, // Set the back arrow to white
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            isLoading
                ? Center(child: CircularProgressIndicator())
                : errorMessage.isNotEmpty
                ? Center(
              child: Text(
                errorMessage,
                style: TextStyle(color: Colors.red),
              ),
            )
                : const SizedBox.shrink(),
            const SizedBox(height: 16),

            // Class Schedule - Subject Info
            if (classDetails.isNotEmpty)
              Expanded(
                child: ListView.builder(
                  itemCount: classDetails.length,
                  itemBuilder: (context, index) {
                    var classInfo = classDetails[index];
                    return Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Card(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                        elevation: 4,
                        child: ListTile(
                          contentPadding: const EdgeInsets.all(12.0),
                          title: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Subject Name
                              Text(
                                "Subject: ${classInfo['subject_name'] ?? 'N/A'}",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.black,
                                ),
                              ),
                              const SizedBox(height: 6),

                              // Class Lecturer
                              Text(
                                "Lecturer: ${classInfo['lecturer_name'] ?? 'N/A'}",
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.blue[800],
                                ),
                              ),
                              const SizedBox(height: 6),

                              // Class Day, Time, and Venue
                              Text(
                                "Day: ${classInfo['day'] ?? 'N/A'}",
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.black,
                                ),
                              ),
                              Text(
                                "Time: ${classInfo['time'] ?? 'N/A'}",
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.black,
                                ),
                              ),
                              Text(
                                "Venue: ${classInfo['venue'] ?? 'N/A'}",
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.black,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Divider(color: Colors.grey[300]),
                            ],
                          ),
                          trailing: IconButton(
                            icon: const Icon(
                              Icons.camera_alt,
                              color: Colors.deepPurple,
                            ),
                            onPressed: () {
                              final scheduleId = classInfo['schedule_id'];
                              if (scheduleId == null) {
                                print("Error: schedule_id is null for classInfo: $classInfo");
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text("Schedule ID not found for this class")),
                                );
                                return;
                              }
                              if (scheduleId is! int) {
                                print("Error: schedule_id is not an integer: $scheduleId");
                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(content: Text("Invalid schedule ID: $scheduleId")),
                                );
                                return;
                              }
                              print("Camera icon tapped for schedule ID: $scheduleId");
                              _takeAttendance(scheduleId);
                            },
                          ),
                        ),
                      ),
                    );
                  },
                ),
              )
            else
              Center(child: Text("No class schedule found.")),
          ],
        ),
      ),
    );
  }
}