import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'ForgotPasswordScreen.dart';
import 'HomeScreen.dart';
import 'SignUpPage.dart';
import '../reusable_widgets/reusable_widget.dart' as reusableWidgets;
import '../utils/color_utils.dart';
import 'package:shared_preferences/shared_preferences.dart';


class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController _emailTextController = TextEditingController();
  TextEditingController _passwordTextController = TextEditingController();

  // Login Function using MySQL
  Future<void> loginUser() async {
    final String url = 'http://192.168.0.18/login.php'; // Your PHP login URL

    final response = await http.post(Uri.parse(url), body: {
      'email': _emailTextController.text,
      'password': _passwordTextController.text,
    });

    if (response.statusCode == 200) {
      final responseBody = jsonDecode(response.body);
      String status = responseBody['status'];

      if (status == 'success') {
        // Save email to SharedPreferences
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString('user_email', _emailTextController.text);
        print("User email saved in SharedPreferences: ${_emailTextController.text}");

        // Navigate to Home screen
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen(email: _emailTextController.text)),
        );
      } else {
        // Error in login, show error message
        String errorMessage = responseBody['message'] ?? 'An unknown error occurred';
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Login Failed'),
            content: Text(errorMessage),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('OK'),
              ),
            ],
          ),
        );
      }
    } else {
      // Handle server or connection errors
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('Error'),
          content: Text('Server error: ${response.statusCode}. Please try again later.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              hexStringToColor("10375C"),
              hexStringToColor("10375C"),
              hexStringToColor("10375C"),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.fromLTRB(
                20, MediaQuery.of(context).size.height * 0.2, 20, 0),
            child: Column(
              children: <Widget>[
                // Logo widget (centered at the top)
                reusableWidgets.logoWidget("assets/images/logo.png"),
                const SizedBox(height: 30),

                // Email TextField (reusable)
                reusableWidgets.reusableTextField("Enter Email", Icons.person_outline, false,
                    _emailTextController),
                const SizedBox(height: 20),

                // Password TextField (reusable)
                reusableWidgets.reusableTextField("Enter Password", Icons.lock_outline, true,
                    _passwordTextController),
                const SizedBox(height: 5),

                // Forgot Password Button (aligned to the right)
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 35,
                  alignment: Alignment.bottomRight,
                  child: TextButton(
                    child: const Text(
                      "Forgot Password?",
                      style: TextStyle(color: Colors.white70),
                      textAlign: TextAlign.right,
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ForgotPasswordScreen()),
                      );
                    },

                  ),
                ),

                // Log In Button (rounded)
                reusableWidgets.firebaseUIButton(context, "LOGIN", () {
                  loginUser();
                }),
                const SizedBox(height: 20),

                // Sign Up Option (centered)
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Text("Don't have an account?", style: TextStyle(color: Colors.white70)),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => SignUpScreen()),
                        );
                      },
                      child: const Text(
                        " Sign Up",
                        style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
