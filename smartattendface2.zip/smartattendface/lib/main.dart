import 'package:flutter/material.dart';
import 'package:smartattendface/screens/LoginPage.dart';
import 'package:smartattendface/screens/SignUpPage.dart';


void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Attendface',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      // Set LoginPage as the home screen
      home: const LoginScreen(),
    );
  }
}