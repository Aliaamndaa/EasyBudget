<?php
include 'db_connect.php';

$email = $_POST['email'];
$query = "SELECT * FROM transactions WHERE email = ? ORDER BY date DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email);
$stmt->execute();

$result = $stmt->get_result();
$transactions = [];

while ($row = $result->fetch_assoc()) {
    $transactions[] = $row;
}

echo json_encode($transactions);

$stmt->close();
$conn->close();
?>
