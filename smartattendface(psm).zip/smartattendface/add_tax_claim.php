<?php
// Include database connection (assuming you have a db_config.php file)
include('db_config.php');

// Check if the required POST parameters are set
if (isset($_POST['email']) && isset($_POST['date'])) {
    $email = $_POST['email'];
    $date = $_POST['date']; // Date in YYYY-MM-DD format (adjust if needed)

    // Function to fetch records from a table for a specific date
    function getRecordsByDate($conn, $email, $table, $date) {
        $query = "SELECT *, '$table' AS type FROM $table WHERE email = ? AND DATE(record_date) = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $email, $date);
        $stmt->execute();
        $result = $stmt->get_result();
        $records = array();
        while ($row = $result->fetch_assoc()) {
            $records[] = $row;
        }
        $stmt->close();
        return $records;
    }

    // Get records from the 'tax_claims' table
    $taxClaims = getRecordsByDate($conn, $email, 'tax_claims', $date);

    // Return the tax claims as JSON
    echo json_encode($taxClaims);

} else {
    // Handle the case where required parameters are missing
    $response = array("error" => "Missing required parameters (email or date).");
    echo json_encode($response);
}

$conn->close();
?>