import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: const [
          ListTile(
            leading: Icon(Icons.person),
            title: Text('User Profile'),
            subtitle: Text('Edit your personal information'),
          ),
          ListTile(
            leading: Icon(Icons.flag),
            title: Text('Financial Goals'),
            subtitle: Text('Set or update your goals'),
          ),
          ListTile(
            leading: Icon(Icons.notifications),
            title: Text('Notifications'),
            subtitle: Text('Enable or disable alerts'),
          ),
          ListTile(
            leading: Icon(Icons.lock),
            title: Text('Privacy & Security'),
            subtitle: Text('Control your data'),
          ),
          ListTile(
            leading: Icon(Icons.download),
            title: Text('Export Data'),
            subtitle: Text('Download a copy of your records'),
          ),
        ],
      ),
    );
  }
}