<?php
// Include database connection
include('db_config.php');

// Get POST values
$email = $_POST['email'];
$date = $_POST['date']; // Expected format: yyyy-MM-dd

// Function to fetch transactions from a table for a specific date
function getTransactionsByDate($conn, $email, $table, $date) {
    // Append % to match any time on the same date
    $date_like = $date . '%';
    $query = "SELECT *, '$table' AS type FROM $table WHERE email = ? AND date LIKE ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $email, $date_like);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $transactions = array();
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }
    $stmt->close();
    return $transactions;
}

// Get transactions from both tables
$expenses = getTransactionsByDate($conn, $email, 'expenses', $date);
$income = getTransactionsByDate($conn, $email, 'income', $date);

// Merge results
$transactions = array_merge($expenses, $income);

// Optional: sort by datetime descending (most recent first)
usort($transactions, function($a, $b) {
    return strtotime($b['date']) - strtotime($a['date']);
});

// Return as JSON
header('Content-Type: application/json');
echo json_encode($transactions);

$conn->close();
?>
