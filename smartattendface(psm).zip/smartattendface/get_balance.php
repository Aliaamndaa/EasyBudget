<?php
header("Content-Type: application/json");
include('db_config.php');

// Validate email from POST
if (!isset($_POST['email'])) {
    echo json_encode(["error" => "Email is required"]);
    exit();
}

$email = $_POST['email'];

// Get total income
$incomeQuery = "SELECT SUM(amount) AS total_income FROM income WHERE email = ?";
$incomeStmt = $conn->prepare($incomeQuery);
$incomeStmt->bind_param("s", $email);
$incomeStmt->execute();
$incomeResult = $incomeStmt->get_result()->fetch_assoc();
$totalIncome = $incomeResult['total_income'] ?? 0.00;

// Get total expenses
$expenseQuery = "SELECT SUM(amount) AS total_expenses FROM expenses WHERE email = ?";
$expenseStmt = $conn->prepare($expenseQuery);
$expenseStmt->bind_param("s", $email);
$expenseStmt->execute();
$expenseResult = $expenseStmt->get_result()->fetch_assoc();
$totalExpenses = $expenseResult['total_expenses'] ?? 0.00;

// Return as JSON
echo json_encode([
    "income" => (float)$totalIncome,
    "expenses" => (float)$totalExpenses
]);

$conn->close();
?>
