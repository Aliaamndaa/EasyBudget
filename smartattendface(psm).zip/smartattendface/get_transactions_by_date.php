<?php
// Include database connection
include('db_connection.php');

$email = $_POST['email']; // Email from the Flutter app
$date = $_POST['date']; // Date parameter from the Flutter app (format: YYYY-MM-DD)

// Query to get all transactions for a specific date
$query = "SELECT * FROM transactions WHERE user_email = ? AND date = ? ORDER BY date DESC";

// Prepare the query
if ($stmt = $conn->prepare($query)) {
    // Bind the parameters
    $stmt->bind_param("ss", $email, $date);

    // Execute the statement
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch all the transactions
    $transactions = array();
    while ($row = $result->fetch_assoc()) {
        $transactions[] = $row;
    }

    // Return the transactions as JSON
    echo json_encode($transactions);

    // Close the statement and connection
    $stmt->close();
} else {
    echo json_encode(["error" => "Failed to execute query."]);
}

$conn->close();
?>
